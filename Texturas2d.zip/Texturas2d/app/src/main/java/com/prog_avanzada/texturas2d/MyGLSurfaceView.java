package com.prog_avanzada.texturas2d;

import android.content.Context;
import android.opengl.GLSurfaceView;
import android.util.AttributeSet;
import com.prog_avanzada.texturas2d.MyGLRenderer;

public class MyGLSurfaceView extends GLSurfaceView {
    private final MyGLRenderer renderer;
    public MyGLSurfaceView(Context context) {
        super(context);
        setEGLContextClientVersion(2);
        renderer = new MyGLRenderer(context);
        setRenderer(renderer);
    }


}
