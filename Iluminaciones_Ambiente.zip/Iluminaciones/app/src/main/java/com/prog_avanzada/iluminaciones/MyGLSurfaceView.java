package com.prog_avanzada.iluminaciones;

import android.content.Context;
import android.opengl.GLSurfaceView;

public class MyGLSurfaceView extends GLSurfaceView {

    private final MyGLRenderer renderer;

    public MyGLSurfaceView(Context context ) {
        super(context);

        setEGLContextClientVersion(2);

        renderer =new MyGLRenderer();
        setRenderer(renderer);
    }
}