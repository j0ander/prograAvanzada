package com.prog_avanzada.iluminaciones;

import android.opengl.GLES20;
import android.opengl.GLSurfaceView;
import android.opengl.Matrix;

import javax.microedition.khronos.egl.EGLConfig;
import javax.microedition.khronos.opengles.GL10;

public class MyGLRenderer implements GLSurfaceView.Renderer {

    private final float[] mProjectionMatrix = new float[16];
    private final float[] mViewMatrix = new float[16];
    private final float[] mvMatrix = new float[16];
    private final float[] mvpMatrix = new float[16];


    private Cube cube;

    private float angle = 0f;

    @Override
    public void onSurfaceCreated(GL10 gl, EGLConfig config) {

        GLES20.glClearColor(1f, 1f, 1f, 1.0f);
        GLES20.glEnable(GLES20.GL_DEPTH_TEST);





        cube = new Cube(0.3f, 0.5f, 4);
        cube.setScale(1f, 1f, 1f);
        cube.setPosition(0f, 0f, 0f);


    }

    @Override
    public void onSurfaceChanged(GL10 gl, int width, int height) {

        GLES20.glViewport(0, 0, width, height);

        float ratio = (float) width / height;

        Matrix.frustumM(
                mProjectionMatrix, 0,
                -ratio, ratio,
                -1, 1,
                2, 20
        );
    }

    @Override
    public void onDrawFrame(GL10 gl) {

        GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT | GLES20.GL_DEPTH_BUFFER_BIT);

        Matrix.setLookAtM(
                mViewMatrix, 0,
                1f, 1f, -3f,
                0f, 0f, 0f,
                0f, 1f, 0f
        );
//        angle += 1;
//        cube.setRotation(angle, 0f, 1f, 0f);

        // ---------- DIBUJO ----------


        drawObject(cube);


    }

    // ---------- METODO REUTILIZABLE ----------
    private void drawObject(Transformable obj) {

        Matrix.multiplyMM(
                mvMatrix, 0,
                mViewMatrix, 0,
                obj.getModelMatrix(), 0
        );

        Matrix.multiplyMM(
                mvpMatrix, 0,
                mProjectionMatrix, 0,
                mvMatrix, 0
        );

        obj.draw(mvpMatrix);
    }

    public static int loadShader(int type, String shaderCode) {
        int shader = GLES20.glCreateShader(type);
        GLES20.glShaderSource(shader, shaderCode);
        GLES20.glCompileShader(shader);
        return shader;
    }
}
