package com.prog_avanzada.iluminaciones;

import android.opengl.Matrix;

public abstract class Transformable {

    private final float[] modelMatrix = new float[16];

    private float posX = 0, posY = 0, posZ = 0;
    private float rotX = 0, rotY = 0, rotZ = 0;
    private float angle = 0;
    private float scaleX = 1, scaleY = 1, scaleZ = 1;

    protected Transformable() {}

    protected void setPosition(float x, float y, float z) {
        posX = x; posY = y; posZ = z;
    }

    protected void setRotation(float angle, float x, float y, float z) {
        this.angle = angle;
        rotX = x; rotY = y; rotZ = z;
    }

    protected void setScale(float x, float y, float z) {
        scaleX = x; scaleY = y; scaleZ = z;
    }



    public float[] getModelMatrix() {
        Matrix.setIdentityM(modelMatrix, 0);

        Matrix.scaleM(modelMatrix, 0, scaleX, scaleY, scaleZ);
        if(angle != 0){
        Matrix.rotateM(modelMatrix, 0, angle, rotX, rotY, rotZ);
        }
        Matrix.translateM(modelMatrix, 0, posX, posY, posZ);

        return modelMatrix;
    }

    public abstract void draw(float[] mvpMatrix);
}

