package com.prog_avanzada.iluminaciones;

import android.opengl.GLES20;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.FloatBuffer;
import java.util.ArrayList;

public class Cube extends Transformable{

    private FloatBuffer bottomBuffer;
    private FloatBuffer topBuffer;
    private FloatBuffer sideBuffer;

    private int bottomCount;
    private int topCount;
    private int sideCount;

    private int mProgram;
    private int positionHandle;
    private int colorHandle;
    private int matrixHandle;
    private int ambienteHandle;

    float ambienteLightColor[] = {0.5f,0.5f,0.5f,1f};

    static final int COORDS_PER_VERTEX = 3;
    static final int STRIDE = COORDS_PER_VERTEX * 4;


    private final String vertexShaderCode =
            "uniform mat4 uMVPMatrix;" +
                    "attribute vec4 vPosition;" +
                    "void main(){" +
                    "    gl_Position = uMVPMatrix * (vPosition);" +
                    "}";

    private final String fragmentShaderCode =
            "precision mediump float;" +
                    "uniform vec4 vColor;" +
                    "uniform vec4 ambientLight;"+
                    "void main(){ gl_FragColor = vColor * ambientLight; }";

    public Cube(float radius, float height, int segments) {

        createBottom(radius, height, segments);
        createTop(radius, height, segments);
        createSide(radius, height, segments);

        int vs = MyGLRenderer.loadShader(GLES20.GL_VERTEX_SHADER, vertexShaderCode);
        int fs = MyGLRenderer.loadShader(GLES20.GL_FRAGMENT_SHADER, fragmentShaderCode);

        mProgram = GLES20.glCreateProgram();
        GLES20.glAttachShader(mProgram, vs);
        GLES20.glAttachShader(mProgram, fs);
        GLES20.glLinkProgram(mProgram);
    }

    private void createBottom(float r, float h, int seg) {

        ArrayList<Float> list = new ArrayList<>();

        float y = -h / 2f;

        list.add(0f); list.add(y); list.add(0f);

        for (int i = 0; i <= seg; i++) {
            double ang = 2 * Math.PI * i / seg;
            list.add((float)(r * Math.cos(ang)));
            list.add(y);
            list.add((float)(r * Math.sin(ang)));
        }

        bottomCount = list.size() / 3;
        bottomBuffer = toBuffer(list);
    }

    private void createTop(float r, float h, int seg) {

        ArrayList<Float> list = new ArrayList<>();

        float y = +h / 2f;

        list.add(0f); list.add(y); list.add(0f);

        for (int i = 0; i <= seg; i++) {
            double ang = 2 * Math.PI * i / seg;
            list.add((float)(r * Math.cos(ang)));
            list.add(y);
            list.add((float)(r * Math.sin(ang)));
        }

        topCount = list.size() / 3;
        topBuffer = toBuffer(list);
    }

    private void createSide(float r, float h, int seg) {

        ArrayList<Float> list = new ArrayList<>();

        float y1 = -h / 2f;
        float y2 = +h / 2f;

        for (int i = 0; i <= seg; i++) {

            double ang = 2 * Math.PI * i / seg;
            float x = (float)(r * Math.cos(ang));
            float z = (float)(r * Math.sin(ang));

            list.add(x); list.add(y1); list.add(z);
            list.add(x); list.add(y2); list.add(z);
        }

        sideCount = list.size() / 3;
        sideBuffer = toBuffer(list);
    }

    public void draw(float[] mvpMatrix) {

        GLES20.glUseProgram(mProgram);

        positionHandle = GLES20.glGetAttribLocation(mProgram, "vPosition");
        colorHandle = GLES20.glGetUniformLocation(mProgram, "vColor");
        matrixHandle = GLES20.glGetUniformLocation(mProgram, "uMVPMatrix");
        GLES20.glUniformMatrix4fv(matrixHandle, 1, false, mvpMatrix, 0);

        GLES20.glEnableVertexAttribArray(positionHandle);

        GLES20.glUniform4fv(colorHandle, 1, new float[]{0.45f, 0.35f, 0.65f, 1.0f}, 0);
        GLES20.glVertexAttribPointer(positionHandle, 3, GLES20.GL_FLOAT, false, STRIDE, bottomBuffer);





        GLES20.glDrawArrays(GLES20.GL_TRIANGLE_FAN, 0, bottomCount);

        GLES20.glVertexAttribPointer(positionHandle, 3, GLES20.GL_FLOAT, false, STRIDE, topBuffer);

        GLES20.glDrawArrays(GLES20.GL_TRIANGLE_FAN, 0, topCount);

        GLES20.glUniform4fv(colorHandle, 1, new float[]{0.45f, 0.35f, 0.65f, 1.0f}, 0);
        GLES20.glVertexAttribPointer(positionHandle, 3, GLES20.GL_FLOAT, false, STRIDE, sideBuffer);


        //Iluminacion Ambiental
        ambienteHandle = GLES20.glGetUniformLocation(mProgram,"ambientLight");
        GLES20.glUniform4fv(ambienteHandle,1,ambienteLightColor,0);

        GLES20.glDrawArrays(GLES20.GL_TRIANGLE_STRIP, 0, sideCount);

        GLES20.glDisableVertexAttribArray(positionHandle);
    }

    private FloatBuffer toBuffer(ArrayList<Float> list) {
        float[] a = new float[list.size()];
        for (int i = 0; i < list.size(); i++) a[i] = list.get(i);

        ByteBuffer bb = ByteBuffer.allocateDirect(a.length * 4);
        bb.order(ByteOrder.nativeOrder());
        FloatBuffer fb = bb.asFloatBuffer();
        fb.put(a);
        fb.position(0);
        return fb;
    }

}