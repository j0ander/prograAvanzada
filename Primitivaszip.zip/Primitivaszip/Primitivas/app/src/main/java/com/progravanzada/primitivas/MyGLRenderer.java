package com.progravanzada.primitivas;
import android.opengl.GLES20;
import android.opengl.GLSurfaceView;

import javax.microedition.khronos.egl.EGLConfig;
import javax.microedition.khronos.opengles.GL10;

public class MyGLRenderer implements GLSurfaceView.Renderer {

    private Point point;
    private Point2 point2;
    private  Point3 punto;

    private Line line;

    private Line1 line1;

    private Triangle trg;
    @Override
    public void onDrawFrame(GL10 gl) {
        GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT);
        point.draw();
//        point2.draw();
//        punto.draw();
        line.draw();
//        line1.draw();
        trg.draw();
    }

    @Override
    public void onSurfaceChanged(GL10 gl, int width, int height) {
        GLES20.glViewport(0,0,width,height);
    }

    @Override
    public void onSurfaceCreated(GL10 gl, EGLConfig config) {
        GLES20.glClearColor(1.0f, 1.0f, 1.0f, 1.0f);
        point = new Point();
//        point2 = new Point2();
//        float[] coords = {
//                -0.5f, 0.5f, 0.0f,   // Punto 1
//                0.0f, 0.0f, 0.0f,   // Punto 2
//                0.5f, -0.5f, 0.0f   // Punto 3
//        };

//        punto = new Point3(coords);
//        punto.setColor(0.7f, 0.85f, 1.0f, 1.0f);
       line = new Line();

//        float[] coordsLinea = {
//                -0.5f, 0.0f,
//                0.5f, 0.0f,
//                0.0f,0.5f,
//                -0.5f, 0.0f
//        };
//
//        line1 = new Line1(coordsLinea);

            trg = new Triangle();
    }
    public static int loadShader(int type, String shaderCode){
        //type puede ser vertex o fragment, a shader se le da un id
        int shader = GLES20.glCreateShader(type);
        //shaderCode en string interpretado por GLES20
        GLES20.glShaderSource(shader, shaderCode);
        //Implementar completamente el shader
        GLES20.glCompileShader(shader);
        return shader;
    }
}