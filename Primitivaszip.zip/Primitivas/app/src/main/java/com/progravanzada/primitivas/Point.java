package com.progravanzada.primitivas;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.FloatBuffer;

public class Point {

    private final FloatBuffer vertexBuffer;
    // almacena coordenadas de manera que OPENGL las pueda interpretar
    private final int mProgram;
    // identificador del programa que une los shaders
    private int positionHandle, colorHandle;
    // ¡IMPORTANTE! Almacenan los identificadores para acceder/identificar a las variables de los shaders
    // Estos tres anteriores son los atributos principales

    //Atributos que trabajan estrictamente con los vertices (para abajo)
    static final int COORDS_POR_VERTE = 3;
    //Esta variable sirve para especificar el tamaño de coordenadas de cada vertice, es decir
    // en este caso 3 coordenadas, x, y, z (en este caso z se dejara en 0 porque estamos en 2D)
    //Indico que cada 3 elementos representan un vertice
    static float pointCoord[] = {0.0f, 0.0f, 0.0f};
    //Define las coordenadas de cada uno de los vertices, se determinan por nosotros
    //Los vertices siempre van a ser arreglos

    //Si dibujo una linea se agregan 3 coordenadas mas (6) y si es un triangulo 3 mas (9), es decir
    //El arreglo de elementos depende estrictamente del numero de vertices

    private final int vertexCount = pointCoord.length/COORDS_POR_VERTE;
    //Sirve para contar el numero de vertices que se van a generar de acuerdo al arreglo

    private final int vertexStride = COORDS_POR_VERTE*4;
    //Nos ayuda a definir cuantos bytes ocupa cada vertice en le buffer
    //Lo normal es que cada vertice como esta lleno de puntos flotantes ocupe 4 bytes, naturaleza 12

    float color [] = {1.0f, 0.75f, 0.45f, 1.0f};
    //Darle color al elemento, es de 4 coordenadas por RGBA

    public Point() {

        ByteBuffer byteBuffer = ByteBuffer.allocateDirect(pointCoord.length*4);
        //Hace la reserva de memoria directa para que la GPU pueda leerla
        // de manera mas rapida y obligatoria en el OPENGL
        byteBuffer.order(ByteOrder.nativeOrder());
        //Sirve para que la ejecucion use el orden de bytes del dispositivo
        //certifica que se lea de acuerdo al orden que viene del arreglo de vertices
        vertexBuffer = byteBuffer.asFloatBuffer();
        //Convertimos el bytebuffer a un buffer de floats por que el arreglo que mandamos es de float
        //Investigar ----
        vertexBuffer.put(pointCoord);
        //Copiar coordenadas del vertice declarado anteriormente al buffer que va a ser enviado al GPU
        vertexBuffer.position(0);
        //Situa el cursor al inicio del buffer para que OPENGL lo lea desde el principio

    }
    // 1. Crea el buffer para enviar las coordenadas a la gpu
    // 2. Compila los shaders
    // 3. Crea el progama opengl para el renderizado
}
