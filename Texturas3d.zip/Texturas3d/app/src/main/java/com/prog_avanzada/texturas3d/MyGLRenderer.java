package com.prog_avanzada.texturas3d;

import android.content.Context;
import android.opengl.GLES20;
import android.opengl.GLSurfaceView;
import android.opengl.Matrix;

import javax.microedition.khronos.egl.EGLConfig;
import javax.microedition.khronos.opengles.GL10;

public class MyGLRenderer implements GLSurfaceView.Renderer {
    private final Context context;

    public MyGLRenderer(Context context){
        this.context = context;
    }

    private final float[] mvpMatrix = new float[16];
    private final float[] projectionMatrix = new float[16];
    private final float[] viewMatrix = new float[16];
    private final float[] modelMatrix = new float[16];
//    private TrianguloTexturizado trianguloTexturizado;
//    private CuadradoTexturizado cuadradoTexturizado;
//    private CirculoTexturizado circuloTexturizado;
    private CuboTexturizado cuboTexturizado;
    private int program;
    private int textureId;
    private float angle = 0;
    @Override
    public void onDrawFrame(GL10 gl) {
        GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT | GLES20.GL_DEPTH_BUFFER_BIT);
        Matrix.setLookAtM(viewMatrix, 0,
                0, 0, 4,   // posición del ojo (x,y,z)
                0f, 0f, 0f,     // mira al centro
                0f, 1f, 0f            //1 hacia arriba
        );
        Matrix.setIdentityM(modelMatrix,0);
        Matrix.rotateM(modelMatrix,0,angle,1,1,0);
        Matrix.multiplyMM(mvpMatrix, 0, viewMatrix, 0, modelMatrix, 0);
        Matrix.multiplyMM(mvpMatrix, 0, projectionMatrix, 0, mvpMatrix, 0);

//        GLES20.glUseProgram(program);
//        GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, textureId);

//        trianguloTexturizado.draw(mvpMatrix);
//        cuadradoTexturizado.draw(mvpMatrix);
//        circuloTexturizado.draw(mvpMatrix);
        cuboTexturizado.draw(mvpMatrix, textureId);
        angle += 1.0f;
    }

    @Override
    public void onSurfaceChanged(GL10 gl, int width, int height) {
        GLES20.glViewport(0,0,width,height);
        float ratio = (float) width / height;
        Matrix.frustumM(projectionMatrix, 0, -ratio, ratio, -1, 1, 2f, 10f);
    }

    @Override
    public void onSurfaceCreated(GL10 gl, EGLConfig config) {
        GLES20.glClearColor(0f,0f,0f,1.0f);
        GLES20.glEnable(GLES20.GL_DEPTH_TEST);

        program = ShaderUtils.createProgram(ShaderUtils.VERTEX_SHADER,ShaderUtils.FRAGMENT_SHADER);

        textureId = ShaderUtils.loadTexture(context,R.drawable.texture2);
        cuboTexturizado = new CuboTexturizado(program);
//        trianguloTexturizado = new TrianguloTexturizado(program);
//        cuadradoTexturizado = new CuadradoTexturizado(program);
//        circuloTexturizado = new CirculoTexturizado(program);

    }
}
