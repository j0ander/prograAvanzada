package com.progra_avanzada.practica1;

import android.opengl.GLES20;
import android.opengl.GLSurfaceView;

import javax.microedition.khronos.egl.EGLConfig;
import javax.microedition.khronos.opengles.GL10;

//coloca(dibuja) el color del renderizado
public class MyGLRenderer implements GLSurfaceView.Renderer {

    //sirve para limpriar y dibujar la pantalla
    @Override
    public void onDrawFrame(GL10 gl) {
        GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT); // LIMPIA LA PANTALLA Y EJECUTA EN CADA FRAME
    }

    //cambiar la orientacion(por defecto vertical, establezer el tamaño de ejecucion)
    @Override
    public void onSurfaceChanged(GL10 gl, int width, int height) {
        GLES20.glViewport(0,0,width/2,height/2); // estos atributos disen que voy a usar toda la pantalla
    }

    //se ejecuta al iniciar la aplicacion (definir el color del fondo de la aplicacion)
    @Override
    public void onSurfaceCreated(GL10 gl, EGLConfig config) {
        GLES20.glClearColor(0.6f,1.0f,0.6f,1.0f);
    }
}
