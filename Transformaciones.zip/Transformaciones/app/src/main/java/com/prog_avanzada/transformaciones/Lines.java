package com.prog_avanzada.transformaciones;

import android.opengl.GLES20;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.FloatBuffer;

public class Lines {

    private final FloatBuffer vertexBuffer;
    private final int mProgram;

    private int positionHandle, colorHandle, mvpMatrixHandle;

    static final int COORDS_POR_VERTEX = 3;

    private final int vertexCount;
    private final int vertexStride;

    // Colores para cada línea (editable con setLineColor)
    private float[][] lineColors;

    public Lines(float[] coords) {

        this.vertexCount = coords.length / COORDS_POR_VERTEX;
        this.vertexStride = COORDS_POR_VERTEX * 4;

        // Número de líneas = cada 2 vértices
        int totalLines = vertexCount / 2;

        // Creamos el arreglo de colores inicial (blanco por defecto)
        lineColors = new float[totalLines][4];
        for (int i = 0; i < totalLines; i++)
            lineColors[i] = new float[]{1f, 1f, 1f, 1f}; // blanco

        ByteBuffer bb = ByteBuffer.allocateDirect(coords.length * 4);
        bb.order(ByteOrder.nativeOrder());

        vertexBuffer = bb.asFloatBuffer();
        vertexBuffer.put(coords);
        vertexBuffer.position(0);

        String vertexShaderCode =
                "uniform mat4 uMVPMatrix;" +
                        "attribute vec4 vPosition;" +
                        "void main(){ gl_Position = uMVPMatrix * vPosition; }";

        String fragmentShaderCode =
                "precision mediump float;" +
                        "uniform vec4 vColor;" +
                        "void main(){ gl_FragColor = vColor; }";

        int v = loadShader(GLES20.GL_VERTEX_SHADER, vertexShaderCode);
        int f = loadShader(GLES20.GL_FRAGMENT_SHADER, fragmentShaderCode);

        mProgram = GLES20.glCreateProgram();
        GLES20.glAttachShader(mProgram, v);
        GLES20.glAttachShader(mProgram, f);
        GLES20.glLinkProgram(mProgram);
    }

    private int loadShader(int type, String code) {
        int shader = GLES20.glCreateShader(type);
        GLES20.glShaderSource(shader, code);
        GLES20.glCompileShader(shader);
        return shader;
    }

    // =============================================
    // MÉTODO PARA CAMBIAR EL COLOR DE UNA LÍNEA
    // =============================================
    public void setLineColor(int lineIndex, float r, float g, float b, float a) {
        if (lineIndex < 0 || lineIndex >= lineColors.length) return;
        lineColors[lineIndex][0] = r;
        lineColors[lineIndex][1] = g;
        lineColors[lineIndex][2] = b;
        lineColors[lineIndex][3] = a;
    }

    public void draw(float[] mvpMatrix) {

        GLES20.glUseProgram(mProgram);

        positionHandle = GLES20.glGetAttribLocation(mProgram, "vPosition");
        colorHandle = GLES20.glGetUniformLocation(mProgram, "vColor");
        mvpMatrixHandle = GLES20.glGetUniformLocation(mProgram, "uMVPMatrix");

        GLES20.glEnableVertexAttribArray(positionHandle);

        GLES20.glVertexAttribPointer(
                positionHandle,
                COORDS_POR_VERTEX,
                GLES20.GL_FLOAT,
                false,
                vertexStride,
                vertexBuffer
        );

        GLES20.glUniformMatrix4fv(mvpMatrixHandle, 1, false, mvpMatrix, 0);

        GLES20.glLineWidth(8);

        int totalLines = vertexCount / 2;

        for (int i = 0; i < totalLines; i++) {

            GLES20.glUniform4fv(colorHandle, 1, lineColors[i], 0);

            int offset = i * 2;

            GLES20.glDrawArrays(GLES20.GL_LINES, offset, 2);
        }

        GLES20.glDisableVertexAttribArray(positionHandle);
    }
}
