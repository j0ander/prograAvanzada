package com.prog_avanzada.transformaciones;

import static com.prog_avanzada.transformaciones.MyGLRenderer.loadShader;

import android.opengl.GLES20;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.FloatBuffer;
import java.nio.ShortBuffer;

public class Piramide {

    private final FloatBuffer vertexBuffer;

    private final ShortBuffer indexBuffer;

    private final int program;

    static final int COORDS_POR_VERTEX = 3;

    static float[] vertices = {
            0.0f, 1.0f, 0.0f, //V0- Punta de la piramide
            -1.0f, -1.0f, 1.0f, //V1 - Vertice izquierdo
            1.0f, -1.0f, 1.0f, //V2 - Vertice derecho
            0.0f, -1.0f, -1.0f //V3 - Vertice de atras
    };
    private final short[] indices = {
            0, 1, 2, //cara frontal
            0, 2, 3, //cara derecha
            0, 3, 1, //cara izquierda
            1, 3, 2 //cara inferior
    };

    public Piramide(){
        ByteBuffer byteBuffer = ByteBuffer.allocateDirect(vertices.length * 4);
        byteBuffer.order(ByteOrder.nativeOrder());
        vertexBuffer = byteBuffer.asFloatBuffer();
        vertexBuffer.put(vertices);
        vertexBuffer.position(0);

        //para el shortBuffer

        ByteBuffer sb =ByteBuffer.allocateDirect(indices.length * 2);
        sb.order(ByteOrder.nativeOrder());
        indexBuffer = sb.asShortBuffer();
        indexBuffer.put(indices);
        indexBuffer.position(0);


        int vertexShader = loadShader(GLES20.GL_VERTEX_SHADER, vertexShaderCode);
        int fragmentShader = loadShader(GLES20.GL_FRAGMENT_SHADER, fragmentShaderCode);
        program = GLES20.glCreateProgram();
        GLES20.glAttachShader(program, vertexShader);
        GLES20.glAttachShader(program, fragmentShader);
        GLES20.glLinkProgram(program);

    }

    String vertexShaderCode =
            "uniform mat4 uMVPMatrix;" +
                    "attribute vec4 vPosition;" +
                    "void main(){ gl_Position = uMVPMatrix * vPosition; }";

    String fragmentShaderCode =
            "precision mediump float;" +
                    "void main(){ gl_FragColor = vec4(0.5, 0.5, 1.0, 1.0); }";

    public void draw(float[] mvpMatrix){
        GLES20.glUseProgram(program);

        int positionHandle = GLES20.glGetAttribLocation(program, "vPosition");
        GLES20.glEnableVertexAttribArray(positionHandle);
        GLES20.glVertexAttribPointer(
                positionHandle,
                COORDS_POR_VERTEX,
                GLES20.GL_FLOAT,
                false,
                0,
                vertexBuffer
        );

        int mvpMatrixHandle = GLES20.glGetUniformLocation(program, "uMVPMatrix");
        GLES20.glUniformMatrix4fv(mvpMatrixHandle, 1, false, mvpMatrix, 0);

        GLES20.glDrawElements(
                GLES20.GL_TRIANGLES,
                indices.length,
                GLES20.GL_UNSIGNED_SHORT,
                indexBuffer
        );

        GLES20.glDisableVertexAttribArray(positionHandle);
    }




}
