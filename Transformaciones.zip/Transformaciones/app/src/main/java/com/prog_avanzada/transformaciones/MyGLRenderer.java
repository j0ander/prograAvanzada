package com.prog_avanzada.transformaciones;

import android.opengl.GLES20;
import android.opengl.GLSurfaceView;
import android.opengl.Matrix;

import javax.microedition.khronos.egl.EGLConfig;
import javax.microedition.khronos.opengles.GL10;

public class MyGLRenderer implements GLSurfaceView.Renderer {

    private final float[] mProjectionMatrix = new float[16];
    private final float[] mViewMatrix = new float[16];
    private final float[] mModelMatrix = new float[16];
    private final float[] mMVPMatrix = new float[16];

    //ROTAR CONTINUAMENTE
    private float angle = 0.0f;


    private Lines lns;
    private Piramide prm;

    @Override
    public void onDrawFrame(GL10 gl) {
        GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT | GLES20.GL_DEPTH_BUFFER_BIT);

        Matrix.setLookAtM(
                mViewMatrix, 0,
                0.0f, 2.0f, -8.0f,   // cámara
                0f, 0f, 0f,         // mira al origen
                0f, 1f, 0f          // arriba = eje Y
        );

        Matrix.setIdentityM(mModelMatrix,0); // Para que el objeto este en el origen
        float[] mvMatrix = new float[16]; //Para que se puedan multiplicar
        Matrix.multiplyMM(mvMatrix,0,mViewMatrix,0,mModelMatrix,0);


        Matrix.multiplyMM(mMVPMatrix, 0, mProjectionMatrix, 0, mvMatrix, 0);

        lns.draw(mMVPMatrix);
        prm.draw(mMVPMatrix);
    }

    @Override
    public void onSurfaceChanged(GL10 gl, int width, int height) {
        GLES20.glViewport(0, 0, width, height);
        float ratio = (float) width / height;
        Matrix.frustumM(
                mProjectionMatrix, 0,
                -ratio, ratio,
                -1, 1,
                2, 10
        );
    }

    @Override
    public void onSurfaceCreated(GL10 gl, EGLConfig config) {

        GLES20.glClearColor(0.0f, 0.0f, 0.0f, 1.0f);
        GLES20.glEnable(GLES20.GL_DEPTH_TEST);

        lns = new Lines(new float[]{
                // EJE X
                -10f, 0f, 0f,
                10f, 0f, 0f,

                // EJE Y
                0f, -10f, 0f,
                0f, 10f, 0f,

                // EJE Z
                0f, 0f, -10f,
                0f, 0f, 10f,
        });
        lns.setLineColor(0, 1, 0, 0, 1); // rojo
        lns.setLineColor(1, 0, 1, 0, 1); // verde
        lns.setLineColor(2, 0, 0, 1, 1); // azul

        prm = new Piramide();
    }

    public static int loadShader(int type, String shaderCode) {
        int shader = GLES20.glCreateShader(type);
        GLES20.glShaderSource(shader, shaderCode);
        GLES20.glCompileShader(shader);
        return shader;
    }
}

