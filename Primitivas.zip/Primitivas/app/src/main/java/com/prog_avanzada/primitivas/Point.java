package com.prog_avanzada.primitivas;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.FloatBuffer;

public class Point {
    private final FloatBuffer vertexBuffer; // nose
    private final int mProgram; //identificador de opengl donde se unen los shaders

    private int positionHandle, colorHandle; //las mas importantes almacenan los identificadores para acceder a las variables de posiciones y colores

    //atributos que trabajan con los vertices(especificar los vertices)

    static final int COORDS_POR_VERTEX = 3; //SIRVE PARA ESPECIFICAR EL TAMAÑO DE COOORDENADAS DE CADA VERTICE

    static float[] pointCoord = {0.0f, 0.0f, 0.0f}; //siempre los vertices van a hacer arreglos(va a guardar las coordenadas del punto) un vertice tiene 3 coordenadas y de eso depende del totalde coordeandas

    private final int vertexCount= pointCoord.length/COORDS_POR_VERTEX; //IDENTIFICAR CUANTOS VERTICES TENGO EN MI FIGURA

    private final int vertexStride = COORDS_POR_VERTEX*4; //CUANTOS BYTES OCUAPA CADA vertice en el buffer (cada vertice ocupe 4 BYTES)

   // float[] color ={1.0f,0.0f,0.0f,1.0f};  //rgba
   float[] color = {0.6392f, 0.2863f, 0.6431f, 1.0f};

  /** public Point(FloatBuffer vertexBuffer, int mProgram, int positionHandle, int colorHandle, float[] color) {
        this.vertexBuffer = vertexBuffer;
        this.mProgram = mProgram;
        this.positionHandle = positionHandle;
        this.colorHandle = colorHandle;
        this.color = color;
    }**/

  public Point(){

      //convierta las coordenadas en buffers ??
      //compilar los shaders ya sea el vertex o el fragment
      //crea el programa opengl para el renderizado

      //1) creacion del buffer:

      ByteBuffer byteBuffer = ByteBuffer.allocateDirect(pointCoord.length*4); //reserva de memoria directa para que la gpu sepa cuantos bits necesita
      byteBuffer.order(ByteOrder.nativeOrder()); // para que la ejecucion use el orden de bytes del dispositivo
      vertexBuffer = byteBuffer.asFloatBuffer(); // estamos convirtiendo el bytebuffer en un buffer de floats
      vertexBuffer.put(pointCoord); //
      vertexBuffer.position(0); // para situar el cursor al inicio del buffer
        // ya puede acceder a las coordenadas por que ya esta tranformadas en un buffer
  }
}
