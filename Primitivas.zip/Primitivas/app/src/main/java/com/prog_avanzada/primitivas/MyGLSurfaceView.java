package com.prog_avanzada.primitivas;

import android.content.Context;
import android.opengl.GLSurfaceView;

//inicializar el opengles
//la vista donde se va a dibujar todo con opengl(liezo)
//OBLIGATORIO QUE EXTIENDA EL GLSURFACEVIEW

public class MyGLSurfaceView extends GLSurfaceView {

    private final MyGLRenderer renderer;

    public MyGLSurfaceView(Context context) {
        super(context);
        setEGLContextClientVersion(2); //version 2 de openglES

        //conexion con la clase renderer (inicializar)

        renderer = new MyGLRenderer();
        setRenderer(renderer);

    }


}
